package com.pedagogy.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class LoginController 
{

	//private LoginServiceI loginservice;
	
	
	public String validateLogin()
	{
		return null;
		
	}
	
	
}
