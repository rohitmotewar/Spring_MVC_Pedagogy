package com.pedagogy.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pedagogy.bean.UserReg;
import com.pedagogy.services.interfaces.UserServiceI;


@Controller
public class UserController 
{
	@Autowired
	private UserServiceI userService;
	
	
	@RequestMapping("/adduser")
	public String addUser(Model model)
	{
		UserReg user=new UserReg();
		
		model.addAttribute("user", user);	
		return "adduser";
	}
	
	@RequestMapping(method=RequestMethod.POST, value="adduser")
	public String addUserMessage(@Valid @ModelAttribute("user") UserReg user,BindingResult result)
	{
		
		System.out.println(" im in controller " + user);
		if(result.hasErrors())
		{
			return "adduser";
		}
		System.out.println(user);
				
		userService.addUser(user);
		
		System.out.println(user);
		return "redirect:/login";
		
	}
		
	//Validate user
	
		@RequestMapping("/login")
		public String validateAdminView(Model model)
		{
			UserReg userReg=new UserReg();
			model.addAttribute("userReg", userReg);
			System.out.println("Model in login is:"+userReg);
			return "login";
		}
	
	@RequestMapping(method=RequestMethod.POST, value="validateuser")
	public String validateUser(@Valid @ModelAttribute("userReg") UserReg user, Model model,BindingResult result)
	{
	//	System.out.println("Email"+email);
		System.out.println("Model received is:" +user);
		if(result.hasErrors())
			return "login";
		
		
		UserReg validated=userService.validateUser(user.getEmail(), user.getPassword(), user.getRole());
		
		
		
		System.out.println("Validator"+validated);
		
		if(validated !=null)	
		{
			if(user.getRole().equals("seeker"))
			{
				return "seekerhome";
			}
			else if(user.getRole().equals("provider"))
			{
				return "providerhome";
			}
			else{
				return "adminhome";
		}
				
			}else{
				return "login";
			}
		
}
}
