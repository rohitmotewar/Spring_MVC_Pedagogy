package com.pedagogy.dao.interfaces;

import java.util.List;

import com.pedagogy.bean.SeekerRequirement;

public interface SeekerRequirementDaoI 
{

	public List<SeekerRequirement> getAllReq();
	
	
}
