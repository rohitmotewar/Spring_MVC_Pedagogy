package com.pedagogy.dao.interfaces;

import com.pedagogy.bean.UserReg;

public interface UserRegI 
{

	public boolean addUser(UserReg user);
	
	public UserReg validateUser(String email,String password,String role);
	
	
}
