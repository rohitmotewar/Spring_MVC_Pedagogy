package com.pedagogy.dao.interfaces;

import com.pedagogy.bean.User;

public interface LoginDaoI 
{
	public User validateUser(User user);
	
}
