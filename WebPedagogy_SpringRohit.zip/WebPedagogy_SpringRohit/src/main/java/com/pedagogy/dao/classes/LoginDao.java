package com.pedagogy.dao.classes;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.pedagogy.bean.User;
import com.pedagogy.dao.interfaces.LoginDaoI;

@Repository //It handles data thats why it is Repository you can user @Service or @Reporsitory
public class LoginDao implements LoginDaoI
{
	@PersistenceContext
	private EntityManager em;

	public User validateUser(User user) 
	{
		Query query = em.createQuery("from User u where u.phoneno=:phoneno and password=:password and role=:role");
			
		user.getPhoneNo();
		user.getPassword();
		user.getRole();
		return user;
		
				
	}

	
	
}
