package com.pedagogy.dao.classes;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import com.pedagogy.bean.UserReg;
import com.pedagogy.dao.interfaces.UserRegI;

@Repository
public class UserRegDao implements UserRegI 
{
	@PersistenceContext
	private EntityManager em;

	@Override
	public boolean addUser(UserReg user) {
		
		System.out.println("Em:"+em);
		em.persist(user);
		System.out.println("User Dao"+user);
		return true;
	}

	@Override
	public UserReg validateUser(String email, String password, String role) {
		
		UserReg validated=em.find(UserReg.class, email);
		
		System.out.println(validated);
			if(validated.getPassword().equals(password) && validated.getRole().equals(role))
			{
				return validated;
			}
			
			else
			{
				return null;		
			}
	}

}
