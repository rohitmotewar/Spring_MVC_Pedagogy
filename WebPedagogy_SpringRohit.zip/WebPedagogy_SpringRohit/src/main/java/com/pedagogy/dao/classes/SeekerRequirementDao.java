package com.pedagogy.dao.classes;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.pedagogy.bean.SeekerRequirement;
import com.pedagogy.dao.interfaces.SeekerRequirementDaoI;

@Repository
public class SeekerRequirementDao implements SeekerRequirementDaoI
{
	
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public List<SeekerRequirement> getAllReq() {
		
		return em.createQuery("from SeekerRequirement").getResultList();
	
	}

	
	
}
