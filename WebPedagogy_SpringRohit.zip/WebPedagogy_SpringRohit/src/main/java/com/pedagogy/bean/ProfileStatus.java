package com.pedagogy.bean;

public class ProfileStatus 
{

	private User user;
	private String status;
	private String comments;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public ProfileStatus(User user, String status, String comments) {
		super();
		this.user = user;
		this.status = status;
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "ProfileStatus [user=" + user + ", status=" + status + ", comments=" + comments + "]";
	}
	
	
}
