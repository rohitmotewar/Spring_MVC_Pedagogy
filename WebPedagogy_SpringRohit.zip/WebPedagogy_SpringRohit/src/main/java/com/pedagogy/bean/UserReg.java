package com.pedagogy.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="user_reg")
public class UserReg 
{
	
	/*@GeneratedValue(strategy=GenerationType.AUTO)
	private int userid;*/
	
	@NotEmpty(message="First Name Cannot be empty")
	private String firstname;
	@NotEmpty(message="Last Name Cannot be empty")
	private String lastname;
	
	@NotEmpty(message="Company Name Cannot be empty")
	private String companyname;
	
	@NotEmpty(message="Phone Number Cannot be empty")
	private String phoneNo;
	
	@NotEmpty(message="Password Cannot be empty")
	private String password;
	private String role;
	
	@NotEmpty(message="Street Cannot be empty")
	private String street;
	@NotEmpty(message="Area Cannot be empty")
	private String area;
	
	@NotEmpty(message="City Cannot be empty")
	private String	city;
	
	@NotEmpty(message="State Cannot be empty")
	private String state;
	
	@NotEmpty(message="Country Cannot be empty")
	private String country;
	
	@Id
	@NotEmpty(message="Email Cannot be empty")
	@Email
	private String email;
	
	
/*	public int getUserId() {
		return userid;
	}
	public void setUserId(int userId) {
		this.userid = userId;
	}*/
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public UserReg(String firstname, String lastname, String companyname, String phoneNo,
			String password, String role, String street, String area, String city, String state, String country,
			String email) {
		super();
		/*this.userid = userId;*/
		this.firstname = firstname;
		this.lastname = lastname;
		this.companyname = companyname;
		this.phoneNo = phoneNo;
		this.password = password;
		this.role = role;
		this.street = street;
		this.area = area;
		this.city = city;
		this.state = state;
		this.country = country;
		this.email = email;
	}
	public UserReg() {
		super();
	}
	@Override
	public String toString() {
		return "UserReg [firstname=" + firstname + ", lastname=" + lastname + ", companyname=" + companyname
				+ ", phoneNo=" + phoneNo + ", password=" + password + ", role=" + role + ", street=" + street
				+ ", area=" + area + ", city=" + city + ", state=" + state + ", country=" + country + ", email=" + email
				+ "]";
	}
	
	
	
	
	
	
	
	
	
}
