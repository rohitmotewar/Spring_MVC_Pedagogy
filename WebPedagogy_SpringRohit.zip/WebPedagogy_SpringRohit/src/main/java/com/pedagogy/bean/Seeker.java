package com.pedagogy.bean;

import java.util.List;

public class Seeker extends User{

	private String firstName;
	private String lastName;
	private String companyName;
	private List<SeekerRequirement> requirementList;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public List<SeekerRequirement> getRequirementList() {
		return requirementList;
	}
	public void setRequirementList(List<SeekerRequirement> requirementList) {
		this.requirementList = requirementList;
	}
	@Override
	public String toString() {
		return "Seeker [firstName=" + firstName + ", lastName=" + lastName + ", companyName=" + companyName
				+ ", requirementList=" + requirementList + "]";
	}
	public Seeker(String firstName, String lastName, String companyName, List<SeekerRequirement> requirementList) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.companyName = companyName;
		this.requirementList = requirementList;
	}
	public Seeker() {
		super();
	}
	
	
}
