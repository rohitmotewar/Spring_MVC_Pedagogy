package com.pedagogy.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seekersrequirement")
public class SeekerRequirement {
	@Id
	private String requirementId;
	private String moduleDescription;
	private int noOfDays;
	private String start_Day;
	private long minBudget;
	private long maxBudget;
	private String location;
	private String training_Level;
	private String takeaways;
	public String getRequirementId() {
		return requirementId;
	}
	public void setRequirementId(String requirementId) {
		this.requirementId = requirementId;
	}
	public String getModuleDescription() {
		return moduleDescription;
	}
	public void setModuleDescription(String moduleDescription) {
		this.moduleDescription = moduleDescription;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public String getStart_Day() {
		return start_Day;
	}
	public void setStart_Day(String start_Day) {
		this.start_Day = start_Day;
	}
	public long getMinBudget() {
		return minBudget;
	}
	public void setMinBudget(long minBudget) {
		this.minBudget = minBudget;
	}
	public long getMaxBudget() {
		return maxBudget;
	}
	public void setMaxBudget(long maxBudget) {
		this.maxBudget = maxBudget;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTraining_Level() {
		return training_Level;
	}
	public void setTraining_Level(String training_Level) {
		this.training_Level = training_Level;
	}
	public String getTakeaways() {
		return takeaways;
	}
	public void setTakeaways(String takeaways) {
		this.takeaways = takeaways;
	}
	public SeekerRequirement(String requirementId, String moduleDescription, int noOfDays, String start_Day,
			long minBudget, long maxBudget, String location, String training_Level, String takeaways) {
		super();
		this.requirementId = requirementId;
		this.moduleDescription = moduleDescription;
		this.noOfDays = noOfDays;
		this.start_Day = start_Day;
		this.minBudget = minBudget;
		this.maxBudget = maxBudget;
		this.location = location;
		this.training_Level = training_Level;
		this.takeaways = takeaways;
	}
	public SeekerRequirement() {
		super();
	}
	@Override
	public String toString() {
		return "SeekerRequirement [requirementId=" + requirementId + ", moduleDescription=" + moduleDescription
				+ ", noOfDays=" + noOfDays + ", start_Day=" + start_Day + ", minBudget=" + minBudget + ", maxBudget="
				+ maxBudget + ", location=" + location + ", training_Level=" + training_Level + ", takeaways="
				+ takeaways + "]";
	}
	
	
	
	
	

}
