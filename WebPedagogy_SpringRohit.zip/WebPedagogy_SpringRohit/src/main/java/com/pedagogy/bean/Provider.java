package com.pedagogy.bean;

import java.util.List;

public class Provider extends User{

	private String firstName;
	private String lastName;
	private String companyName;
	private String dateOfBirth;
	private String pancardNo;
	private String gstNo;
	private List<ProviderSkills> skillList;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getGstNo() {
		return gstNo;
	}
	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}
	public List<ProviderSkills> getSkillList() {
		return skillList;
	}
	public void setSkillList(List<ProviderSkills> skillList) {
		this.skillList = skillList;
	}
	@Override
	public String toString() {
		return "Provider [firstName=" + firstName + ", lastName=" + lastName + ", companyName=" + companyName
				+ ", dateOfBirth=" + dateOfBirth + ", pancardNo=" + pancardNo + ", gstNo=" + gstNo + ", skillList="
				+ skillList + "]";
	}
	public Provider(String firstName, String lastName, String companyName, String dateOfBirth, String pancardNo,
			String gstNo, List<ProviderSkills> skillList) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.companyName = companyName;
		this.dateOfBirth = dateOfBirth;
		this.pancardNo = pancardNo;
		this.gstNo = gstNo;
		this.skillList = skillList;
	}
	public Provider() {
		super();
	}
	
	
}
