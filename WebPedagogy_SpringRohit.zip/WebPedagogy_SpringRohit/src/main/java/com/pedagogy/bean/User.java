package com.pedagogy.bean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pedagogy_users")
public class User implements Serializable 
{
	
	@Id
	private String userId;
	
	private String email;
	
	private String password;
	
	private String phoneNo;
	
	private String role;
	
	/*@ManyToOne
	@JoinColumn(name="addressid")
	private List<Address> addressList;
	
	private ProfileStatus profileStatus;*/
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	/*public List<Address> getAddressList() {
		return addressList;
	}
	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}
	public ProfileStatus getProfileStatus() {
		return profileStatus;
	}
	public void setProfileStatus(ProfileStatus profileStatus) {
		this.profileStatus = profileStatus;
	}*/
	public User(String userId, String email, String password, String phoneNo, String role, List<Address> addressList,
			ProfileStatus profileStatus) {
		super();
		this.userId = userId;
		this.email = email;
		this.password = password;
		this.phoneNo = phoneNo;
		this.role = role;
		/*this.addressList = addressList;
		this.profileStatus = profileStatus;*/
	}
	public User() {
		super();
	}

	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", email=" + email + ", password=" + password + ", phoneNo=" + phoneNo
				+ ", role=" + role + "]";
	}
	
	
	
	
	
}
