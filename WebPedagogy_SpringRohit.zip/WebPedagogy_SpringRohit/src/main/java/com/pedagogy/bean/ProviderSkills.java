package com.pedagogy.bean;

public class ProviderSkills {

	private User user;
	private String skillId;
	private String skillName;
	private int rating;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getSkillId() {
		return skillId;
	}
	public void setSkillId(String skillId) {
		this.skillId = skillId;
	}
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "ProviderSkills [user=" + user + ", skillId=" + skillId + ", skillName=" + skillName + ", rating="
				+ rating + "]";
	}
	public ProviderSkills(User user, String skillId, String skillName, int rating) {
		super();
		this.user = user;
		this.skillId = skillId;
		this.skillName = skillName;
		this.rating = rating;
	}
	public ProviderSkills() {
		super();
	}
	
	
	
}
