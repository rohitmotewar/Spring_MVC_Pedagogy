package com.pedagogy.services.interfaces;


import com.pedagogy.bean.UserReg;

public interface UserServiceI 
{
	public boolean addUser(UserReg user);
	public UserReg validateUser(String email,String password,String role);
	
}
