package com.pedagogy.services.classes;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pedagogy.bean.UserReg;
import com.pedagogy.dao.interfaces.UserRegI;
import com.pedagogy.services.interfaces.UserServiceI;

@Component
public class UserService implements UserServiceI
{
	@Autowired
	private UserRegI userDao;

	@Transactional
	@Override
	public boolean addUser(UserReg user) {
		
		userDao.addUser(user);
		return true;
	}

	@Override
	public UserReg validateUser(String email, String password, String role) {
		
		return userDao.validateUser(email, password, role);
		
	}
	

}
