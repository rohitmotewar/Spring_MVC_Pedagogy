package com.pedagogy.services.interfaces;

import java.util.List;

import com.pedagogy.bean.SeekerRequirement;

public interface SeekerRequirementI 
{
	public List<SeekerRequirement> getAllReq();
	
}
