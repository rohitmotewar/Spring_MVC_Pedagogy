package com.pedagogy.services.classes;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pedagogy.bean.SeekerRequirement;
import com.pedagogy.dao.interfaces.SeekerRequirementDaoI;
import com.pedagogy.services.interfaces.SeekerRequirementI;

@Component
public class SeekerRequirementService implements SeekerRequirementI
{
	@Autowired
	private SeekerRequirementDaoI seekerreqdao;

	@Override
	public List<SeekerRequirement> getAllReq() {
		
		return seekerreqdao.getAllReq();
		
	}

	
}
